package com.fatec.lojinha;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente,Integer> {

    @Query(value = "select * from cliente where email = ?1 and senha = ?2 limit 1", nativeQuery = true)
    Cliente login(String email, String senha);

    @Query(value = "select * from cliente where email = ?1 limit 1", nativeQuery = true)
    Cliente buscarPorEmail(String email);

}
