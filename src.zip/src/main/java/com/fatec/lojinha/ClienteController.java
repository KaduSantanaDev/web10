package com.fatec.lojinha;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class ClienteController {
    @Autowired
    ClienteRepository bd;

    @Autowired
    JavaMailSender mail;

    @Value("${spring.mail.username}")
    String remetente;

    @PostMapping("/api/cliente/login")
    public Cliente login(@RequestBody Cliente obj){
        Cliente cliente = bd.login(obj.getEmail(), obj.getSenha());
        if(cliente != null){
            return cliente;
        } else {
            return new Cliente();
        }
    }

    @PostMapping("/api/cliente/reenviarSenha")
    public String reenviarSenha(@RequestBody Cliente obj){
        Cliente cliente = bd.buscarPorEmail(obj.getEmail());
        if(cliente == null){
            return "Cliente não encontrado!";
        }
        SimpleMailMessage mensagem = new SimpleMailMessage();
        mensagem.setFrom(remetente);
        mensagem.setTo(cliente.getEmail());
        mensagem.setSubject("Lojinha - Reenvio de senha");
        mensagem.setText("Olá " + cliente.getNome() + ", sua senha é: " + cliente.getSenha());
        try {
            mail.send(mensagem);
            return "Senha reenviada para o e-mail " + cliente.getEmail();
        } catch (MailException e) {
            return "Erro ao reenviar a senha!";
        }
    }

    @GetMapping("/api/cliente/{codigo}")
    public Cliente retorna(@PathVariable("codigo") int id){
        if(bd.existsById(id)){
            return bd.findById(id).get();
        } else {
            return new Cliente();
        }
    }

    @PostMapping("/api/cliente")
    public String gravar(@RequestBody Cliente obj){
        bd.save(obj);
        return "Cliente gravado com sucesso! "+ obj.getCodigo();
    }
   
    @PutMapping("/api/cliente")
    public String alterar(@RequestBody Cliente obj){
        if(bd.existsById(obj.getCodigo())){
            bd.save(obj);
            return "Cliente alterado com sucesso! "+ obj.getCodigo();
        } else {
            return "Cliente não encontrado!";
        }
    }

    @DeleteMapping("/api/cliente/{codigo}")
    public String apagar(@PathVariable("codigo") int id){
        bd.deleteById(id);
        return "Cliente removido com sucesso!";
    }


}
